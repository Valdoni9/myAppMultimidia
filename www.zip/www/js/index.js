// Memory Game
// © 2014 Nate Wiley
// License -- MIT
// best in full screen, works on phones/tablets (min height for game is 500px..) enjoy ;)
// Follow me on Codepen

(function(){
	
	var Memory = {

		init: function(cards){
			this.$game = $(".game");
			this.$modal = $(".modal");
			this.$overlay = $(".modal-overlay");
			this.$restartButton = $("button.restart");
			this.cardsArray = $.merge(cards, cards);
			this.shuffleCards(this.cardsArray);
			this.setup();
		},

		shuffleCards: function(cardsArray){
			this.$cards = $(this.shuffle(this.cardsArray));
		},

		setup: function(){
			this.html = this.buildHTML();
			this.$game.html(this.html);
			this.$memoryCards = $(".card");
			this.paused = false;
     	this.guess = null;
			this.binding();
		},

		binding: function(){
			this.$memoryCards.on("click", this.cardClicked);
			this.$restartButton.on("click", $.proxy(this.reset, this));
		},
		// kinda messy but hey
		cardClicked: function(){
			var _ = Memory;
			var $card = $(this);
			if(!_.paused && !$card.find(".inside").hasClass("matched") && !$card.find(".inside").hasClass("picked")){
				$card.find(".inside").addClass("picked");
				if(!_.guess){
					_.guess = $(this).attr("data-id");
				} else if(_.guess == $(this).attr("data-id") && !$(this).hasClass("picked")){
					$(".picked").addClass("matched");
					_.guess = null;
				} else {
					_.guess = null;
					_.paused = true;
					setTimeout(function(){
						$(".picked").removeClass("picked");
						Memory.paused = false;
					}, 600);
				}
				if($(".matched").length == $(".card").length){
					_.win();
				}
			}
		},

		win: function(){
			this.paused = true;
			setTimeout(function(){
				Memory.showModal();
				Memory.$game.fadeOut();
			}, 1000);
		},

		showModal: function(){
			this.$overlay.show();
			this.$modal.fadeIn("slow");
		},

		hideModal: function(){
			this.$overlay.hide();
			this.$modal.hide();
		},

		reset: function(){
			this.hideModal();
			this.shuffleCards(this.cardsArray);
			this.setup();
			this.$game.show("slow");
		},

		// Fisher--Yates Algorithm -- https://bost.ocks.org/mike/shuffle/
		shuffle: function(array){
			var counter = array.length, temp, index;
	   	// While there are elements in the array
	   	while (counter > 0) {
        	// Pick a random index
        	index = Math.floor(Math.random() * counter);
        	// Decrease counter by 1
        	counter--;
        	// And swap the last element with it
        	temp = array[counter];
        	array[counter] = array[index];
        	array[index] = temp;
	    	}
	    	return array;
		},

		buildHTML: function(){
			var frag = '';
			this.$cards.each(function(k, v){
				frag += '<div class="card" data-id="'+ v.id +'"><div class="inside">\
				<div class="front"><img src="'+ v.img +'"\ alt="'+ v.name +'" /></div>\
				<div class="back">		<img src="http://envolverde.cartacapital.com.br/wp-content/uploads/water-art-wallpaper-20.jpg"\
				alt="Codepen"/></div></div></div>\
				</div>';
			});
			return frag;
		}
	};

	var cards = [
		{
			name: "Dourado",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Dourado-6-300x189.jpg",
			id: 1,
		},
		{
			name: "Pacu",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Pacu-4-300x200.jpg",
			id: 2
		},
		{
			name: "Pintado",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Pintado-6-300x200.jpg",
			id: 3
		},
		{
			name: "Piraputanga",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Piraputanga-4-300x225.jpg",
			id: 4
		}, 
		{
			name: "Cachara",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Cachara-1-300x200.jpg",
			id: 5
		},
		{
			name: "Barbado",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/barbado-300x171.jpg",
			id: 6
		},
		{
			name: "Pacu Peva",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Pacu-Peva-1-300x225.jpg",
			id: 7
		},
		{
			name: "Corvina",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Corvina-1-300x208.jpg",
			id: 8
		},
		{
			name: "PIAVUÇÚ",
			img: "http://www.pousadabarradoarica.com.br/wp-content/uploads/2019/01/Piau%C3%A7u-2-300x200.jpg",
			id: 9
		},
		{
			name: "Curimba",
			img: "http://3.bp.blogspot.com/-RBP7IHGqoFA/T6BYBgxtfcI/AAAAAAAAC68/Yxgbg1GTUi8/s640/BXK3963_peixe-no-rio-da-prata-bonito-ms800.jpg",
			id: 10
		},
		{
			name: "Pirá tamanduá",
			img: "https://sites.google.com/site/ranchopescandodourado/_/rsrc/1467898603917/fotos-peixes-1/hqdefault.jpg",
			id: 11
		},
		{
			name: "Piracema",
			img: "http://1.bp.blogspot.com/_2LMkC3uJDFM/S7dN8awWXpI/AAAAAAAAABY/9ESkuSxotGg/s1600/piracema.JPG",
			id: 12
		},
	];
    
	Memory.init(cards);


})();