angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('cameraTabDefaultPage', {
    url: '/page2',
    templateUrl: 'templates/cameraTabDefaultPage.html',
    controller: 'cameraTabDefaultPageCtrl'
  })

  .state('cartTabDefaultPage', {
    url: '/page3',
    templateUrl: 'templates/cartTabDefaultPage.html',
    controller: 'cartTabDefaultPageCtrl'
  })

  .state('cloudTabDefaultPage', {
    url: '/page4',
    templateUrl: 'templates/cloudTabDefaultPage.html',
    controller: 'cloudTabDefaultPageCtrl'
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('vamosConhecerNossoMatoGrosso', {
    url: '/page5',
    templateUrl: 'templates/vamosConhecerNossoMatoGrosso.html',
    controller: 'vamosConhecerNossoMatoGrossoCtrl'
  })

  .state('nobres', {
    url: '/page6',
    templateUrl: 'templates/nobres.html',
    controller: 'nobresCtrl'
  })

  .state('pantanal', {
    url: '/page7',
    templateUrl: 'templates/pantanal.html',
    controller: 'pantanalCtrl'
  })

  .state('chapada', {
    url: '/page8',
    templateUrl: 'templates/chapada.html',
    controller: 'chapadaCtrl'
  })

  .state('home', {
    url: '/page9',
    templateUrl: 'templates/home.html',
    controller: 'homeCtrl'
  })

  .state('memoria_gamer',{
    url: '/page10',
    templateUrl: 'templates/memoria_gamer.html',
    controller: 'memoria_gamerCtrl'

  })

$urlRouterProvider.otherwise('/page5')


});